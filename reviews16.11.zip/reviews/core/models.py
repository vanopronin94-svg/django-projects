from django.db import models
class ReviewModel(models.Model):
    name=models.CharField(max_length=25)
    email=models.EmailField()
    review=models.TextField()
    rating=models.IntegerField()